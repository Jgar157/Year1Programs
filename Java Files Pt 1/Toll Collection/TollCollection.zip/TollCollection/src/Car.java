/* Author: Jairo Garciga
 * Date: 2/19/20
 * The Car class is used to make unique vehicles each time
 * It also uses static variables as accumulators for totals.
 */


public class Car {
	
	//These variables are declared static so that they can exist out of a specific class.
	private static double totalCashCost = 0;
	private static double totalCardCost = 0;
	private static double totalElectronicCost = 0;
	
	//Each of these methods are used to get their respective total.
	static double getTotalCashCost() {
		return totalCashCost;
	}
	
	static double getTotalCardCost() {
		return totalCardCost;
	}
	
	static double getTotalElectronicCost() {
		return totalElectronicCost;
	}
	
	//Declaration and instantiation of all variables for future use.
	private int axleCount = 0;
	private String vehicleType = "";
	private String paymentType = "";
	
	private double cashCost = 0;
	private double cardCost = 0;
	private double electronicCost = 0;
	private double finalPayment = 0;
	
	//The arrays for costs are arranged as a double array for each type of Car
	//The axles are the columns and the cash type are the rows.

	//[x][0]=1 axle and [x][3]=3+ axles| axles  1    2     3     3+
	private double[][] evCostByaxle = 	   {{1.00, 2.00, 4.00, 4.00}, //Cash for EV
											{1.50, 3.00, 5.50, 5.50}, // Credit/Debit
											{0.50, 0.50, 1.00, 0.50}}; //Electronic
	
	private double[][] hybridCostByaxle =  {{1.50, 3.00, 4.00, 5.00 }, //Cash for EV
											{2.00, 4.00, 5.50, 6.50}, // Credit/Debit
											{1.00, 1.50, 3.00, 4.50}}; //Electronic
	
	private double[][] gasolineCostByaxle ={{3.00, 4.00, 6.00, 8.00 }, //Cash for EV
											{3.50, 5.00, 7.50, 9.50}, // Credit/Debit
											{2.50, 3.50, 5.00, 10.00}}; //Electronic
	
	//Constructor that takes three inputs
	public Car(String carType, int axles, String paymentType) {
		
		vehicleType = carType;
		
		//In order to avoid having issues with axles later on 
		//(Because axles will be used as elements to access elements of the arrays of costs)
		//all axles after 4 are just set to 4.
		if (axles > 4) {
			axleCount = 4;
		}
		
		else {
			axleCount = axles;
		}
		
		//This section determines the cost of each vehicle dependent on what vehicle type the user inputs
		//it then sets all of the costs for cash, card, and electronic.
		//The method paymentMethod() then determines what cost will be the one selected.
		if (carType.equalsIgnoreCase("EV")) {
			cashCost = evCostByaxle[0][axleCount-1];
			cardCost = evCostByaxle[1][axleCount-1];
			electronicCost = evCostByaxle[2][axleCount-1];
		}
		
		else if (carType.equalsIgnoreCase("Hybrid")) {
			cashCost = hybridCostByaxle[0][axleCount-1];
			cardCost = hybridCostByaxle[1][axleCount-1];
			electronicCost = hybridCostByaxle[2][axleCount-1];
		}
		//Automatic choosing of electronic if the input for CarType is bad.
		else {
			cashCost = gasolineCostByaxle[0][axleCount-1];
			cardCost = gasolineCostByaxle[1][axleCount-1];
			electronicCost = gasolineCostByaxle[2][axleCount-1];
		}
		
		//Calls payment method which then assigns the final cost to the paymentType the user inputed.
		this.paymentMethod(paymentType);
		
	}
	
	//Checks to see which payment type the user input and then sets the appropriate cost to the final Cost.
	public void paymentMethod(String paymentType) {
		if (paymentType.equalsIgnoreCase("Cash")) {
			finalPayment = cashCost;
			totalCashCost += finalPayment;
		}
		
		else if(paymentType.equalsIgnoreCase("Card")) {
			finalPayment = cardCost;
			totalCardCost += finalPayment;
		}
		
		//Automatically chooses electronic if the input for the payment is bad.
		else {
			finalPayment = electronicCost;
			totalElectronicCost += finalPayment;
		}
	}
	
	//A getter for the tollRate so that the main class can access it.
	public double getTollRate() {
		return finalPayment;
	}
}